TOKEN = '6568443707:AAGCNMc-Um3ROYc3mKVNDy7OTDSIKJkLpL4'
adress_deposit = 'krwqewqpelwq'
database_info = {
    'host': '127.0.0.1',
    'port': 3306,
    'user': 'root',
    'password': 'Monexo2023',
    'name': 'masters'
}
link_bot = 't.me/master_follow_bot'
banner_photo_id = 'AgACAgIAAxkBAAICG2TaEFu0tx5fDHBebm7KUmPaqaHCAAIz0zEbC_TQSgqwP0bat-TPAQADAgADcwADMAQ'
percents_one_line = 50
percent_others = 3
